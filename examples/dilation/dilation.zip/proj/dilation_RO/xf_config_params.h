/* Optimization type */

#define RO 1 // Resource Optimized (8-pixel implementation)
#define NO 0 // Normal Operation (1-pixel implementation)
